<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        $users = [
			[
				'name' => 'Stanislas',
				'email' => 'info@joytech.in',
				'password' => Hash::make('password'),
			],
			[
				'name' => 'Martina Monica',
				'email' => 'martina@joytech.com',
				'password' => Hash::make('password'),
			],
			[
				'name' => 'Maria Foustina',
				'email' => 'maria@joytech.com',
				'password' => Hash::make('password'),
			],
			[
				'name' => 'Princy',
				'email' => 'princy@joytech.com',
				'password' => Hash::make('password'),
			]
		];
		foreach ($users as $user) {
            User::create($user);
        }
    }
}
