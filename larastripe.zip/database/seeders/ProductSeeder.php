<?php

namespace Database\Seeders;

use App\Models\Products;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {
        for ($i=1; $i <= 15; $i++) {
            Products::create([
                'name' => 'Gift Toy '.$i,
                'slug' => rand(999, 99999).$i,
                'details' => 'Gift Shop toys / Birthday Wedding and Love Gifts',
                'description' =>'Lorem '. $i . ' ipsum dolor sit amet, consectetur adipisicing elit. Ipsum temporibus iusto ipsa, asperiores voluptas unde aspernatur praesentium in? Aliquam, dolore!',
                'main_image' => 'images/products/main_image/'.$i.'.png',
                'product_code' => 'JOYGT-0'.$i,
                'price' => rand(999, 9999),
                'quantity' => rand(1,10),
            ]);
        }
    }
}
