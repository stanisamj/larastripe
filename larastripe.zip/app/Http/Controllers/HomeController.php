<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Products;
use App\Models\User;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
		$featured = Products::where('main_image', '!=', 'defaults/no_image.jpg')->inRandomOrder()->get(['name', 'price', 'product_code', 'slug', 'main_image']);
		return view('home', compact('featured'));
    }
	
	public function show($slug)
    {
		$featured = Products::where('main_image', '!=', 'defaults/no_image.jpg')->take(4)->inRandomOrder()->get(['name', 'price', 'product_code', 'slug', 'main_image']);
		$prodetail = Products::where('slug', $slug)->first();
		$user = Auth::user();
		$intentval = $user->createSetupIntent();
        return view('productdetail', compact('prodetail', 'featured', 'intentval', 'user'));
    }
	
	public function processPayment(Request $request, String $product, $price)
	{
		$user = Auth::user();
		$paymentMethod = $request->input('token');
		
		try {
			$user->createOrGetStripeCustomer();
			$user->updateDefaultPaymentMethod($paymentMethod);			
			$user->charge($price * 100, $paymentMethod,[
				 'return_url' => route('payment.completed'),
			]);        
		} catch (\Exception $exception) {
			return back()->with('error', $exception->getMessage());
		}
		return back()->with('message', 'Product purchased successfully!');
	}
	
	public function completePayment()
	{
		return view('thankyou');
	}
	
	
}
