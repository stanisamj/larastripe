@extends('layouts.app')

@section('content')
<div class="container-fluid big-padding bg-white about-cover">
        <div class="container">
            @if(session('message'))
				<div class="alert alert-success" role="alert">{{ session('message') }}</div>
			@endif
			@if(session('error'))
				<div class="alert alert-danger" role="alert">{{ session('error') }}</div>
			@endif
			
			<div class="row about-row">
                <div class="col-md-4 text-center">
                    <img src="{{ url('assets/'.$prodetail->main_image) }}" alt="">
                </div>
                <div class="col-md-4">
                    <h2>{{ $prodetail->name }}</h2>
                    <p>{{ $prodetail->details }}</p>
                    <b class="fs-3 py-4 text-danger">₹ {{ $prodetail->price }}</b>
                     
                    <ul class="key-features mt-2">
                        <li><i class="bi bi-caret-right"></i> {{ $prodetail->slug }}</li>
                        <li><i class="bi bi-caret-right"></i> {{ $prodetail->product_code }}</li>
                        <li><i class="bi bi-caret-right"></i> {{ $prodetail->quantity }}</li>
                    </ul>
                </div>
				<div class="col-md-4">
					<div class="login-card bg-white shadow-md p-5">
						<form id="payment-form" action="{{route('processPayment', ['Welcome Product', $prodetail->price])}}" method="POST">
                        @csrf
                        <input type="hidden" name="product_id" id="product_id" value="{{ $prodetail->id }}">
  
                        <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label for="">Name</label>
                                    <input type="text" name="name" id="card-holder-name" class="form-control" value="{{$user->name}}" placeholder="Name on the card" />
                                </div>
                            </div>
                        </div>
						
						<div class="row ">
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label for="">Price in USD</label>
                                    ₹ {{ number_format($prodetail->price, 2) }}
                                </div>
                            </div>
                        </div>
						
  
                        <div class="row mt-5">
                            <div class="col-xl-12 col-lg-12 ">
                                <div class="form-group">
                                    <label for="">Card details</label>
                                    <div class="mt-3" id="card-element"></div>
                                </div>
                            </div>
						</div>
						<div class="row mt-5">
                            <div class="col-xl-12 col-lg-12">
								<div class="form-group">
                                <button type="submit" class="btn btn-info" id="card-button" data-secret="{{ $intentval->client_secret }}">Pay Now </button>
								</div>
                            </div>
                        </div>
  
                    </form>
					</div>
				</div>
            </div>
            <div class="row product-detail mt-5">
               <h4>Product Detail</h4>
			   <p class="mb-3">{{ $prodetail->description }}</p>
                <p class="mb-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eu velit nec neque tempus commodo. Mauris dictum nunc vitae elit porta blandit. Proin non laoreet odio. Sed aliquet, turpis sodales mattis fringilla, massa nulla iaculis justo, sit amet imperdiet libero orci eget neque. Morbi tincidunt vehicula vulputate. Vestibulum efficitur accumsan scelerisque. Nulla rutrum neque id nunc aliquam suscipit. Fusce eget arcu aliquet, gravida massa non, fringilla sem. Cras sapien dui, varius vitae nisi eget, tristique mattis justo. Fusce auctor consequat leo, ac mattis sem fermentum condimentum. Suspendisse ultrices elementum diam eget lobortis. Morbi et libero odio. Sed rutrum augue eget ante laoreet finibus.</p>
                <p class="mb-3">Suspendisse pellentesque feugiat nunc, a finibus eros mollis at. Proin lorem nisi, commodo vitae nibh sit amet, tempor posuere neque. Vivamus lobortis est nec libero maximus, feugiat iaculis sem laoreet. Suspendisse porta egestas justo, feugiat gravida turpis. Quisque ut tristique nibh, vel auctor erat. Proin eget finibus diam. Sed in tortor vitae risus elementum iaculis.</p>
                <p class="mb-3">Quisque vitae est elit. Phasellus sed quam felis. Sed eget nisi varius, finibus eros vitae, porta quam. Aliquam pulvinar placerat placerat. Nulla at mattis sem. Nam eget auctor massa, et tristique lacus. Sed lacus dolor, commodo ac blandit sit amet, lacinia id quam. Vivamus hendrerit risus id lectus convallis, quis feugiat ligula auctor. Curabitur ante nulla, vestibulum a eros vitae, ultricies molestie purus. Maecenas sed elit nec sapien tristique tincidunt. Aliquam laoreet nulla ac metus mattis viverra. Fusce hendrerit, augue eget hendrerit pellentesque, lorem nulla condimentum massa, efficitur pellentesque tortor sapien sed lectus. Nullam et lorem ut turpis finibus facilisis in vel orci. Nunc vitae urna sit amet libero scelerisque efficitur. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eget lectus imperdiet, scelerisque nunc id, pharetra metus.</p>
            </div>
            
            </div>
        </div>
        
        <div class="container-fluid big-padding relatrd">
           <div class="container">
               <div class="section-tile row">
                   <div class="col-md-10 mb-4 text-center mx-auto">
                         <h2>Related Products</h2>
                   </div>
                </div>
               <div class="row">
                    @foreach($featured as $product)
                    <div class="col-lg-3 col-md-4 mb-4">
                        <div class="bg-white p-2 shadow-md">
                           <div class="text-center">
                               <a href="detail.html">
                                    <img src="{{ url('assets/'.$product['main_image']) }}" alt="">
                               </a>
                           </div>
                            <div class="detail p-2">
                                <h4 class="mb-1 fs-5 fw-bold">{{ $product['name'] }} <small>-{{ $product['product_code'] }}</small></h4>
                                <b class="fs-4 text-danger">₹ {{ $product['price'] }}</b>
                                <div class="row pt-2">
                                    <div class="col-md-12">
                                        <a href="{{ url('products/'.$product['slug']) }}">
                                            <button class="btn mb-2 fw-bold w-100 btn-danger">Buy Now</button>
                                        </a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach 
                    
                    
                    
               </div>
           </div>
        </div>


<script src="https://js.stripe.com/v3/"></script>
<script>
    const stripe = Stripe('{{ env('STRIPE_KEY') }}')
  
    const elements = stripe.elements()
    const cardElement = elements.create('card')
  
    cardElement.mount('#card-element')
  
    const form = document.getElementById('payment-form')
    const cardBtn = document.getElementById('card-button')
    const cardHolderName = document.getElementById('card-holder-name')
  
    form.addEventListener('submit', async (e) => {
        e.preventDefault()
  
        cardBtn.disabled = true
        const { setupIntent, error } = await stripe.confirmCardSetup(
            cardBtn.dataset.secret, {
                payment_method: {
                    card: cardElement,
                    billing_details: {
                        name: cardHolderName.value
                    }   
                }
            }
        )
		console.log(setupIntent);
  
        if(error) {
            cardBtn.disable = false;
			console.log(setupIntent);
			$('#card-errors').text(result.error.message)
        } else {
			console.log(setupIntent);
            let token = document.createElement('input')
            token.setAttribute('type', 'hidden')
            token.setAttribute('name', 'token')
            token.setAttribute('value', setupIntent.payment_method)
            form.appendChild(token)
            form.submit();
        }
    })
</script>
@endsection