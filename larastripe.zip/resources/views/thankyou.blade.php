@extends('layouts.app')

@section('content')
<div class="container-fluid big-padding about-cover">
        <div class="container">
            <div class="row about-row">
                <div class="col-md-6 no-padding image">
                    <img src="assets/images/blog/2.jpg" alt="">
                </div>
                <div class="col-md-6 detail ps-4 ">
                    <h2>Thank You</h2>
                    <p>Your Payment Successfully Completed!!!</p>
                </div>
            </div>
        </div>
    </div>        
@endsection