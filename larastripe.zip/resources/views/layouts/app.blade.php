<!doctype html>
    <html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- CSRF Token -->
		<meta name="csrf-token" content="{{ csrf_token() }}">
        <title>{{ config('app.name', 'Laravel') }}</title>
        <link rel="shortcut icon" href="{{ asset('assets/images/fav.png') }}" type="image/x-icon">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&amp;display=swap" rel="stylesheet">
        <link rel="shortcut icon" href="{{ asset('assets/images/fav.jpg') }}">
        <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
        <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/style.css') }}" />
		@vite(['resources/sass/app.scss', 'resources/js/app.js'])
    </head>
	
	<body>
		<div id="app">
			<header class="container-fluid bg-white">
            
				<div class="logo-contaienr p-2">
					 <div class="container">
						 <div class="row">
							 <div class="col-md-3 col-9 pt-1 pb-2">
								<a href="{{ url('/home') }}">
									<img class="logo" src="{{ asset('assets/images/logo.jpg') }}" alt="">
								</a>
							 </div>
							 <div class="col-md-6 d-none d-md-block pt-2">
								  <ul class="d-inline-flex pt-0 pt-md-2 fs-6">
									<li class="p-2 "><i class="bi bi-envelope"></i> stanisamj@gmail.com</li>
									<li class="p-2 d-none d-md-block"><i class="bi bi-headphones"></i> +91 9677901175</li>
								</ul>
							 </div>
							 <div class="col-md-3 col-3 pt-1 text-end">
								
							 
							 
							 
								<ul class="ms-auto d-inline-flex">
									@guest
										@if (Route::has('login'))
											<li class="nav-item p-2">
												<a class="nav-link" href="{{ route('login') }}"><button class="btn px-4 btn-danger">Login</button></a>
											</li>
										@endif

										@if (Route::has('register'))
											<li class="nav-item p-2">
												<a class="nav-link" href="{{ route('register') }}"><button class="btn px-4 btn-outline-danger">Register</button></a></a>
											</li>
										@endif
									@else
										<li class="nav-item dropdown">
											<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
												{{ Auth::user()->name }}
											</a>

											<div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
												<a class="dropdown-item" href="{{ route('logout') }}"
												   onclick="event.preventDefault();
																 document.getElementById('logout-form').submit();">
													{{ __('Logout') }}
												</a>

												<form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
													@csrf
												</form>
											</div>
										</li>
									@endguest
								</ul>
								
							 </div>
						 </div>
					 </div>   
				</div>
            <div class="menu-bar bg-danger container-fluid border-top">
                <div class="container">
                   <h6 class="d-md-none text-white p-3 mb-0 fw-bold">Menu 
                  <a class="text-white" data-bs-target="#menu" data-bs-toggle="collapse" aria-expanded="false" aria-controls="menu"><i class="bi cp bi-list float-end fs-1 dmji"></i></a> 
                   </h6>
                    <ul id="menu" class=" navcol fw-bold d-none d-md-inline-flex">
                        <li class="p-21 px-4"><a class="text-white" href="">Categories <i class="bi pt-2 bi-chevron-down"></i></a> 
                            <div class="inner-div">
                                <ul class="">
                                    <li><a href="">Baby</a></li>
                                    <li><a href="">Beauty & Personal Care</a></li>
                                    <li><a href="">Business & Executive Gifts</a></li>
                                    <li><a href="">Chocolates & Cookies</a></li>
                                    <li><a href="">Computer & Mobile Accessories</a></li>
                                    <li><a href="">Flowers & Cakes</a></li>
                                    <li><a href="">Garden Gifts</a></li>
                                    <li><a href="">Gag & Quirky Gifts</a></li>
                                    <li><a href="">Gift Baskets & Hampers</a></li>
                                    <li><a href="">Gift Cards</a></li>
                                    <li><a href="">Home & Living</a></li>
                                    <li><a href="">Jewellery</a></li>
                                    <li><a href="">Love & Romance</a></li>
                                </ul>
                            </div>
                        </li>
                          <li class="p-21 px-4"><a class="text-white" href="">Pages <i class="bi pt-2 bi-chevron-down"></i></a> 
                            <div class="inner-div">
                                <ul class="">
                                    <li><a href="index.html">Home</a></li>
                                    <li><a href="about.html">About US</a></li>
                                    <li><a href="contact.html">Contact US</a></li>
                                    <li><a href="product.html">Product Listing</a></li>
                                    <li><a href="detail.html">Product Detail</a></li>
                                    <li><a href="login.html">login</a></li>
                                    <li><a href="signup.html">Sing Up</a></li>
                                    <li><a href="cart.html">Cart</a></li>
                                </ul>
                            </div>
                        </li>
                        <li class="p-21 px-4"><a class="text-white" href="">Anniversary <i class="bi pt-2 bi-chevron-down"></i></a></li>
                        <li class="p-21 px-4"><a class="text-white" href="">Birthday <i class="bi pt-2 bi-chevron-down"></i></a></li>
                        <li class="p-21 px-4"><a class="text-white" href="">Personal <i class="bi pt-2 bi-chevron-down"></i></a></li>
                        <li class="p-21 px-4"><a class="text-white" href="">Reception <i class="bi pt-2 bi-chevron-down"></i></a></li>
                        <li class="p-21 px-4"><a class="text-white" href="">Occasions </a></li>
                        
                        <li class="p-21 px-4"><a class="text-white" href="">Surprise </a></li>
                    </ul>
                </div>
            </div>
        </header>
			<main class="py-4">
				@yield('content')
			</main>
		</div>
		<footer>
        <div class="inner">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 foot-about">
                        <h4>About US</h4>

                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras hendrerit libero pellentesque libero interdum, id mattis felis dictum. Praesent eget lacus tempor justo efficitur malesuada. Cras ut suscipit nisi.</p>

                        <ul>
                            <li>10/2 Banker Colony</li>
                            <li>info@joytech.in</li>
                            <li>+91 9677901175</li>
                        </ul>
                    </div>

                    <div class="col-md-3 foot-post">
                        <h4>Latest Posts</h4>

                        <div class="post-row">
                            <div class="image">
                                <img src="assets/images/blog/blog_01.jpg" alt="">
                            </div>
                            <div class="detail">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras hendrerit </p>
                            </div>
                        </div>

                        <div class="post-row">
                            <div class="image">
                                <img src="assets/images/blog/blog_02.jpg" alt="">
                            </div>
                            <div class="detail">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras hendrerit </p>
                            </div>
                        </div>

                        <div class="post-row">
                            <div class="image">
                                <img src="assets/images/blog/blog_03.jpg" alt="">
                            </div>
                            <div class="detail">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras hendrerit </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 foot-services">
                        <h4>Top Category</h4>

                        <ul>
                            <li><a href="">Target Statergy</a></li>
                            <li><a href="">Web Analytics</a></li>
                            <li><a href="">Page Monitering</a></li>
                            <li><a href="">Page Optimization</a></li>
                            <li><a href="">Target Statergy</a></li>
                            <li><a href="">Email Marketing</a></li>
                        </ul>
                    </div>

                    <div class="col-md-3 foot-news">
                        <h4>News Letter</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam justo neque, vehicula eget eros. </p>

                        <div class="input-group mb-3">
                            <input type="text" class="form-control mb-0" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <span class="input-group-text bg-danger" id="basic-addon2"><i class="bi text-white bi-send"></i></span>
                            </div>
                        </div>

                        <ul>
                            <li><i class="bi bi-facebook"></i></li>
                            <li><i class="bi bi-twitter"></i></li>
                            <li><i class="bi bi-instagram"></i></li>
                            <li><i class="bi bi-linkedin"></i></li>
                            <li><i class="bi bi-pinterest"></i></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="copy">
        <div class="container">
            <a href="#">2024 &copy; Joy Info Tech</a>

            <span>
                <a href=""><i class="fab fa-github"></i></a>
                <a href=""><i class="fab fa-google-plus-g"></i></a>
                <a href="https://in.pinterest.com/prabnr/pins/"><i class="fab fa-pinterest-p"></i></a>
                <a href="https://twitter.com/prabinraja89"><i class="fab fa-twitter"></i></a>
                <a href="https://www.facebook.com/freewebtemplatesbysmarteye"><i class="fab fa-facebook-f"></i></a>
            </span>
        </div>
    </div>
	</body>
	<script src="{{asset('assets/js/jquery-3.2.1.min.js') }}"></script>
    <script src="{{asset('assets/js/popper.min.js') }}"></script>
    <script src="{{asset('assets/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{asset('assets/plugins/scroll-fixed/jquery-scrolltofixed-min.js') }}"></script>
    <script src="{{asset('assets/plugins/testimonial/js/owl.carousel.min.js') }}"></script>
    <script src="{{asset('assets/js/script.js') }}"></script>
</html>
