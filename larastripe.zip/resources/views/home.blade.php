@extends('layouts.app')

@section('content')
<div class="slider">
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="{{ asset('assets/images/slider/s1.jpg') }}" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="{{ asset('assets/images/slider/s2.jpg') }}" class="d-block w-100" alt="...">
                </div>
               
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
        </div>
        
        <div class="latest-products pt-5 pb-0">
            <div class="container-xl">
                <div class="section-tile row">
                   <div class="col-md-10 text-center mx-auto">
                         <h2>Featured Products</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sit amet est sit amet sem malesuada bibendum. Nulla eget mauris at dolor fermentum blandit. Maecenas</p>
                   </div>
                </div>
                <div class="row mt-5">
					@foreach($featured as $product)
                    <div class="col-lg-3 col-md-4 mb-4">
                        <div class="bg-white p-2 shadow-md">
                           <div class="text-center">
                               <a href="detail.html">
                                    <img src="{{ url('assets/'.$product['main_image']) }}" alt="">
                               </a>
                           </div>
                            <div class="detail p-2">
                                <h4 class="mb-1 fs-5 fw-bold">{{ $product['name'] }} <small>-{{ $product['product_code'] }}</small></h4>
                                <b class="fs-4 text-danger">₹ {{ $product['price'] }}</b>
                                <div class="row pt-2">
                                    <div class="col-md-12">
                                        <a href="{{ url('products/'.$product['slug']) }}">
                                            <button class="btn mb-2 fw-bold w-100 btn-danger">Buy Now</button>
                                        </a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach                    
                </div>
            </div>
        </div>
@endsection
