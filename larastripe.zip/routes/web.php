<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

Route::get('/', function () {
    return view('auth/login');
});

Auth::routes();

Route::get('/home', [HomeController::class, 'index'])->name('home');

Route::middleware("auth")->group(function () {
    Route::get('products/{slug}', [HomeController::class, 'show'])->name("products.show");
	Route::post('payment/process-payment/{string}/{price}', [HomeController::class, 'processPayment'])->name('processPayment');
	Route::post('payment/completed', [HomeController::class, 'completePayment'])->name('payment.completed');
});
